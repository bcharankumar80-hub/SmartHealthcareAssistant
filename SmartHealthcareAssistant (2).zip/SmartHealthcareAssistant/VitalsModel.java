import java.io.Serializable;

public class VitalsModel implements Serializable {
    private String userName;
    private int heartRate;
    private int sysBP;
    private int diaBP;
    private double waterIntake;
    private double sleepHours;

    public VitalsModel(String userName, int heartRate, int sysBP, int diaBP, double waterIntake, double sleepHours) {
        this.userName = userName != null ? userName.trim() : "";
        this.heartRate = heartRate;
        this.sysBP = sysBP;
        this.diaBP = diaBP;
        this.waterIntake = waterIntake;
        this.sleepHours = sleepHours;
    }

    public boolean isVipUser() {
        if (userName == null || userName.isEmpty()) return false;
        String cleanName = userName.trim().replaceAll("[\\s.]+", "").toLowerCase();
        return cleanName.equals("divya") ||
               cleanName.equals("divyasri") ||
               cleanName.equals("bdivyasri") ||
               cleanName.equals("barmadivyasri");
    }

    public int calculateWellnessScore() {
        int score = 100;
        if (heartRate < 60 || heartRate > 100) score -= 15;
        if (heartRate < 50 || heartRate > 120) score -= 10;
        if (sysBP > 120 || diaBP > 80) score -= 15;
        if (sysBP > 140 || diaBP > 90) score -= 10;
        if (waterIntake < 2.5) score -= 10;
        if (waterIntake < 1.5) score -= 10;
        if (sleepHours < 7.0) score -= 15;
        if (sleepHours < 5.0) score -= 15;
        return Math.max(score, 0);
    }

    public String evaluateHealthStatus() {
        if (heartRate < 50 || heartRate > 120 || sysBP > 140 || diaBP > 90 || sleepHours < 4) {
            return "CRITICAL WARNING";
        } else if (heartRate < 60 || heartRate > 100 || sysBP > 125 || waterIntake < 2.0 || sleepHours < 6) {
            return "NEEDS ATTENTION";
        } else {
            return "OPTIMAL / HEALTHY";
        }
    }

    public String getDetailedBreakdown() {
        StringBuilder sb = new StringBuilder("<html><body style='width:240px; font-family:Arial; font-size:11px; line-height: 1.4;'>");
        if (isVipUser()) {
            sb.append("<div style='background-color: #fff0f5; padding: 6px; border-left: 3px solid #ff1493; margin-bottom: 8px;'>")
              .append("<b>👑 VIP PLATINUM HEALTH TIER</b><br>")
              .append("<b>Wellness Score: ").append(calculateWellnessScore()).append("/100</b>")
              .append("</div>");
        }
        sb.append("<b>❤️ Heart Rate (").append(heartRate).append(" bpm):</b><br>");
        if (heartRate >= 60 && heartRate <= 100) {
            sb.append("<font color='#008000'>Normal resting rate. Rhythm stable.</font><br><br>");
        } else if (heartRate < 60) {
            sb.append("<font color='#ff8c00'>Bradycardia (Low). Rest recommended.</font><br><br>");
        } else {
            sb.append("<font color='#ff0000'>Tachycardia (High). Relax and breathe.</font><br><br>");
        }
        sb.append("<b>🩺 Blood Pressure (").append(sysBP).append("/").append(diaBP).append(" mmHg):</b><br>");
        if (sysBP <= 120 && diaBP <= 80) {
            sb.append("<font color='#008000'>Optimal vascular range.</font><br><br>");
        } else if (sysBP <= 139 || diaBP <= 89) {
            sb.append("<font color='#ff8c00'>Prehypertension. Monitor sodium.</font><br><br>");
        } else {
            sb.append("<font color='#ff0000'>High BP Alert! Immediate rest needed.</font><br><br>");
        }
        sb.append("<b>💧 Water Intake (").append(waterIntake).append(" L):</b><br>");
        if (waterIntake >= 2.5) {
            sb.append("<font color='#008000'>Hydration level is great.</font><br><br>");
        } else {
            sb.append("<font color='#ff8c00'>Low hydration. Drink 500ml water.</font><br><br>");
        }
        sb.append("<b>💤 Sleep (").append(sleepHours).append(" hrs):</b><br>");
        if (sleepHours >= 7.0) {
            sb.append("<font color='#008000'>Adequate rest achieved.</font>");
        } else {
            sb.append("<font color='#ff0000'>Sleep deficit! Aim for 7-8 hours.</font>");
        }
        sb.append("</body></html>");
        return sb.toString();
    }

    public String toLogEntry() {
        String vipTag = isVipUser() ? "[VIP] " : "";
        return String.format("%sUser: %s | HR: %d bpm | BP: %d/%d mmHg | Water: %.1f L | Sleep: %.1f hrs | Status: %s",
                vipTag, userName, heartRate, sysBP, diaBP, waterIntake, sleepHours, evaluateHealthStatus());
    }
}
