import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class SmartHealthGUI extends JFrame {
    private JTextField txtUserName, txtHeartRate, txtSysBP, txtDiaBP, txtWater, txtSleep;
    private JLabel lblStatus, lblMotivationalTip;
    private JPanel statusPanel, mainDashboardPanel;
    private JCheckBox chkMorningMed, chkEveningMed;

    public SmartHealthGUI() {
        setTitle("Personal Smart Healthcare Assistant");
        setSize(760, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new GridLayout(2, 1));
        JLabel lblHeader = new JLabel("🏥 Personal Smart Healthcare Assistant", SwingConstants.CENTER);
        lblHeader.setFont(new Font("Arial", Font.BOLD, 22));
        lblHeader.setBorder(BorderFactory.createEmptyBorder(12, 0, 2, 0));

        JLabel lblTeam = new JLabel(
                "Team Members: B. CHARAN KUMAR  |  B. VASU  |  SAI ADHITH",
                SwingConstants.CENTER);
        lblTeam.setFont(new Font("Arial", Font.PLAIN, 12));
        lblTeam.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        headerPanel.add(lblHeader);
        headerPanel.add(lblTeam);
        add(headerPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 12, 12));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JPanel inputPanel = new JPanel(new GridLayout(7, 2, 8, 8));
        inputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Daily Vitals Input",
                TitledBorder.LEFT, TitledBorder.TOP, new Font("Arial", Font.BOLD, 14)));

        inputPanel.add(new JLabel("User Name:"));
        txtUserName = new JTextField("");
        inputPanel.add(txtUserName);
        inputPanel.add(new JLabel("Heart Rate (BPM):"));
        txtHeartRate = new JTextField("");
        inputPanel.add(txtHeartRate);
        inputPanel.add(new JLabel("Systolic BP (mmHg):"));
        txtSysBP = new JTextField("");
        inputPanel.add(txtSysBP);
        inputPanel.add(new JLabel("Diastolic BP (mmHg):"));
        txtDiaBP = new JTextField("");
        inputPanel.add(txtDiaBP);
        inputPanel.add(new JLabel("Water Intake (L):"));
        txtWater = new JTextField("");
        inputPanel.add(txtWater);
        inputPanel.add(new JLabel("Sleep Duration (hrs):"));
        txtSleep = new JTextField("");
        inputPanel.add(txtSleep);

        JButton btnAnalyze = new JButton("Evaluate Vitals");
        btnAnalyze.setFont(new Font("Arial", Font.BOLD, 13));
        btnAnalyze.setBackground(new Color(60, 130, 240));
        btnAnalyze.setForeground(Color.WHITE);
        inputPanel.add(btnAnalyze);

        mainDashboardPanel = new JPanel(new BorderLayout(5, 5));
        mainDashboardPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Detailed Metric Analysis",
                TitledBorder.LEFT, TitledBorder.TOP, new Font("Arial", Font.BOLD, 14)));

        statusPanel = new JPanel(new GridBagLayout());
        statusPanel.setBackground(new Color(220, 245, 220));
        lblStatus = new JLabel("STATUS: OPTIMAL / HEALTHY");
        lblStatus.setFont(new Font("Arial", Font.BOLD, 15));
        lblStatus.setForeground(new Color(20, 100, 20));
        statusPanel.add(lblStatus);
        mainDashboardPanel.add(statusPanel, BorderLayout.NORTH);

        lblMotivationalTip = new JLabel("<html><p style='width:240px;'>Enter metrics and click 'Evaluate Vitals'.</p></html>");
        lblMotivationalTip.setFont(new Font("Arial", Font.PLAIN, 12));
        lblMotivationalTip.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JScrollPane scrollPane = new JScrollPane(lblMotivationalTip);
        scrollPane.setBorder(null);
        mainDashboardPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel medPanel = new JPanel(new GridLayout(2, 1));
        medPanel.setBorder(BorderFactory.createTitledBorder("Daily Medication Reminder"));
        chkMorningMed = new JCheckBox("Morning Vitamins / Supplements");
        chkEveningMed = new JCheckBox("Evening Prescriptions");
        medPanel.add(chkMorningMed);
        medPanel.add(chkEveningMed);
        mainDashboardPanel.add(medPanel, BorderLayout.SOUTH);

        centerPanel.add(inputPanel);
        centerPanel.add(mainDashboardPanel);
        add(centerPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        JButton btnReset = new JButton("Reset");
        btnReset.setFont(new Font("Arial", Font.BOLD, 13));
        JButton btnSave = new JButton("Save Daily Log to File");
        btnSave.setFont(new Font("Arial", Font.BOLD, 13));
        bottomPanel.add(btnReset);
        bottomPanel.add(btnSave);
        add(bottomPanel, BorderLayout.SOUTH);

        btnAnalyze.addActionListener(e -> analyzeVitals());
        btnSave.addActionListener(e -> saveLogToFile());
        btnReset.addActionListener(e -> resetForm());
    }

    // Clears current entries and dashboard; saved history remains untouched.
    private void resetForm() {
        txtUserName.setText("");
        txtHeartRate.setText("");
        txtSysBP.setText("");
        txtDiaBP.setText("");
        txtWater.setText("");
        txtSleep.setText("");
        chkMorningMed.setSelected(false);
        chkEveningMed.setSelected(false);

        lblStatus.setText("STATUS: OPTIMAL / HEALTHY");
        lblStatus.setForeground(new Color(20, 100, 20));
        statusPanel.setBackground(new Color(220, 245, 220));
        mainDashboardPanel.setBackground(UIManager.getColor("Panel.background"));
        lblMotivationalTip.setText("<html><p style='width:240px;'>Enter metrics and click 'Evaluate Vitals'.</p></html>");
        txtUserName.requestFocusInWindow();
    }

    private VitalsModel getVitalsFromForm() throws NumberFormatException {
        String name = txtUserName.getText();
        int hr = Integer.parseInt(txtHeartRate.getText().trim());
        int sys = Integer.parseInt(txtSysBP.getText().trim());
        int dia = Integer.parseInt(txtDiaBP.getText().trim());
        double water = Double.parseDouble(txtWater.getText().trim());
        double sleep = Double.parseDouble(txtSleep.getText().trim());
        return new VitalsModel(name, hr, sys, dia, water, sleep);
    }

    private void analyzeVitals() {
        try {
            VitalsModel vitals = getVitalsFromForm();
            String status = vitals.evaluateHealthStatus();
            lblMotivationalTip.setText(vitals.getDetailedBreakdown());

            if (vitals.isVipUser()) {
                mainDashboardPanel.setBackground(new Color(255, 240, 245));
                statusPanel.setBackground(new Color(255, 215, 0));
                lblStatus.setForeground(new Color(120, 40, 90));
                int score = vitals.calculateWellnessScore();
                lblStatus.setText("👑 DIVYA'S  PLATINUM TIER [" + score + "/100]");
            } else {
                mainDashboardPanel.setBackground(UIManager.getColor("Panel.background"));
                lblStatus.setText("STATUS: " + status);
                if (status.equals("OPTIMAL / HEALTHY")) {
                    statusPanel.setBackground(new Color(210, 245, 210));
                    lblStatus.setForeground(new Color(20, 100, 20));
                } else if (status.equals("NEEDS ATTENTION")) {
                    statusPanel.setBackground(new Color(255, 245, 200));
                    lblStatus.setForeground(new Color(150, 100, 0));
                } else {
                    statusPanel.setBackground(new Color(255, 210, 210));
                    lblStatus.setForeground(new Color(180, 0, 0));
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numeric values for all vitals.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveLogToFile() {
        try {
            VitalsModel vitals = getVitalsFromForm();
            boolean success = FileManager.saveLog(vitals);
            if (success) {
                JOptionPane.showMessageDialog(this, "Daily health log saved successfully!",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save log file.",
                        "File Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please check your inputs before saving.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SmartHealthGUI().setVisible(true));
    }
}
