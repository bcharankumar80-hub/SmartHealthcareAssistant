# Personal Smart Healthcare Assistant

A Java Swing desktop application for entering daily health vitals, viewing health feedback, marking medication reminders, and saving daily health logs.

## Team Members
- B. CHARAN KUMAR
- B. VASU
- SAI ADHITH

## Requirements
- Java JDK 17 or later
- No external libraries required

## Files
- SmartHealthGUI.java — Swing interface, including the Reset button
- VitalsModel.java — health-status evaluation, wellness score, and detailed feedback
- FileManager.java — appends daily logs to health_log_history.txt

## Run
Open a terminal in this folder and run:

    javac SmartHealthGUI.java VitalsModel.java FileManager.java
    java SmartHealthGUI

## Reset button
Reset clears the current vital-entry fields, medication checkboxes, and dashboard display. It does not delete saved records in health_log_history.txt.

## Saved history
The Save Daily Log button appends records with timestamps to health_log_history.txt in the current working directory.
